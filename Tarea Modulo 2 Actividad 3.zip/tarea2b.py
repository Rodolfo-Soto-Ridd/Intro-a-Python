cantidad = int(input("ingresa la cantidad de alumnos para conocer su situacion de aprobación:"))
contador = 1
nombres = []
comentarios = []
while contador <= cantidad:
    nombre = input("ingresa tu nombre:")
    matematica = int(input("ingresa tu calificación de matemáticas obtenida - entre 0 y 100:"))
    ciencia = int(input("ingresa tu calificación de ciencias obtenida - entre 0 y 100:"))
    ingles = int(input("ingresa tu calificación de ingles obtenida - entre 0 y 100:"))
    comentario = input("Agregar comentario:")
    calificacion = int((matematica + ciencia + ingles)/3)
    print("tu calificacion promedio es:", calificacion)
    if calificacion >90:
        print("Excelente")
    elif calificacion <= 90 and calificacion >= 75:
        print("Bueno")
    else:
        print("Necesita Mejorar")
    if calificacion >= 60:
        print("tu calificación promedio es aprobatoria")
    else:
        print("tu calificacion promedio es reprobatoria")
    mensaje = "Puntaje Perfecto" if calificacion == 100 else " "
    print(mensaje)
    nombres.append(nombre)
    comentarios.append(comentario)
    contador +=1
for nombre, comentario in zip(nombres, comentarios):
    print(f"Los alumnos(as) que consultaron su situación y sus comentarios fueron, respectivamente: {nombre, comentario}")