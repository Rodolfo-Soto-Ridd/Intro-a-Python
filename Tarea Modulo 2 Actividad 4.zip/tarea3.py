largo = float(input("Ingrese el largo del rectangulo en [m]:"))
ancho = float(input("Ingrese el ancho del rectangulo en [m]:"))
def calcular_area_rectangulo(largo,ancho):
    return largo*ancho
resultado = calcular_area_rectangulo(largo,ancho)
print("El área del rectangulo es de en [m]:",resultado)

import math
radio = float(input("Ingrese el radio del circulo en [m]:"))
def calcular_circunferencia(radio):
    return 2*(math.pi)*radio
result = calcular_circunferencia(radio)
print("La circunferencia del circulo es en [m]:", result)

cantidad = int(input("Ingrese la cantidad de numeros de lo que quiere obtener el promedio:"))
contador = 1
datos = []
while contador <= cantidad:
    dato = float(input("Ingrese el valor a promediar:"))
    datos.append(dato)
    contador +=1
import statistics 
media = statistics.mean(datos)
print("La media de los datos ingresados es de:", media)
from statistics import mean 
calcular_promedio_avanzado = mean(datos)
print("El promedio avanzado de los datos ingresados es de:",calcular_promedio_avanzado)

import random
def generar_numeros_aletaorios():
    cantidad_numeros = int(input("Ingrese la cantidad de numeros aleatorios que requiere:"))
    limite = int(input("Ingrese el limite superior, del rango de numeros aleatorios que se comprenderán entre 1 y limite superior (solo de aceptan numeros enteros):"))
    numero = random.sample(range(1,limite), cantidad_numeros)  
    print("Los numeros aleatorios solicitados son:",numero)
generar_numeros_aletaorios()
